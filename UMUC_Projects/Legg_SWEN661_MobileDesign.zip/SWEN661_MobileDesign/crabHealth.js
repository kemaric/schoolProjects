new Vue({
    el: '#container',
    data: {
      value: '',
    },
  });