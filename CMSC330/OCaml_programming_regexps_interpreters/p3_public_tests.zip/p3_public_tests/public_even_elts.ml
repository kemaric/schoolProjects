#use "testUtils.ml";;
#use "hide.ml";;
#use "warmup.ml";;

prt_int_list (even_elts [0]);;
prt_int_list (even_elts [0;1;2]);;
prt_int_list (even_elts [0;1;2;3;4]);;
prt_int_list (even_elts [0;1;2;3;4;5;6]);;
prt_int_list (even_elts [0;1;2;3;4;5;6;7;8]);;
prt_int_list (even_elts [0;1;2;3;4;5;6;7;8;9;10]);;
prt_int_list (even_elts [0;1;2;3;4;5;6;7;8;9;10;11;12]);;
prt_int_list (even_elts [0;1;2;3;4;5;6;7;8;9;10;11;12;13;14]);;
prt_int_list (even_elts [0;1;2;3;4;5;6;7;8;9;10;11;12;13;14;15;16]);;
prt_int_list (even_elts [0;1;2;3;4;5;6;7;8;9;10;11;12;13;14;15;16;17;18]);;
