#use "testUtils.ml";;
#use "hide.ml";;
#use "warmup.ml";;

prt_int_list (rotate 2 [0]);;
prt_int_list (rotate 2 [0;1]);;
prt_int_list (rotate 2 [0;1;2]);;
prt_int_list (rotate 2 [0;1;2;3]);;
prt_int_list (rotate 2 [0;1;2;3;4]);;
prt_int_list (rotate 2 [0;1;2;3;4;5]);;
prt_int_list (rotate 2 [0;1;2;3;4;5;6]);;
prt_int_list (rotate 2 [0;1;2;3;4;5;6;7]);;
prt_int_list (rotate 2 [0;1;2;3;4;5;6;7;8]);;
